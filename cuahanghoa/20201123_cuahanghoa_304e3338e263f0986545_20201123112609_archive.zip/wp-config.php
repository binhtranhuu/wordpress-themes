<?php
/**
 * Cấu hình cơ bản cho WordPress
 *
 * Trong quá trình cài đặt, file "wp-config.php" sẽ được tạo dựa trên nội dung 
 * mẫu của file này. Bạn không bắt buộc phải sử dụng giao diện web để cài đặt, 
 * chỉ cần lưu file này lại với tên "wp-config.php" và điền các thông tin cần thiết.
 *
 * File này chứa các thiết lập sau:
 *
 * * Thiết lập MySQL
 * * Các khóa bí mật
 * * Tiền tố cho các bảng database
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Thiết lập MySQL - Bạn có thể lấy các thông tin này từ host/server ** //
/** Tên database MySQL */
define( 'DB_NAME', '' );


/** Username của database */
define( 'DB_USER', '' );


/** Mật khẩu của database */
define( 'DB_PASSWORD', '' );


/** Hostname của database */
define( 'DB_HOST', '' );


/** Database charset sử dụng để tạo bảng database. */
define( 'DB_CHARSET', 'utf8mb4' );


/** Kiểu database collate. Đừng thay đổi nếu không hiểu rõ. */
define('DB_COLLATE', '');

/**#@+
 * Khóa xác thực và salt.
 *
 * Thay đổi các giá trị dưới đây thành các khóa không trùng nhau!
 * Bạn có thể tạo ra các khóa này bằng công cụ
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * Bạn có thể thay đổi chúng bất cứ lúc nào để vô hiệu hóa tất cả
 * các cookie hiện có. Điều này sẽ buộc tất cả người dùng phải đăng nhập lại.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pD-CYi$YEFQ>umO^&?Ga#r&>xWu2Tz5 kR59k:Xun>y.W-gwA/v8Wh^{d,CYWWx6' );

define( 'SECURE_AUTH_KEY',  ';<CxprpuRw%!TtJkwx{@&$jWPJeWG|0b|>o:$)Qo8:^pEJ[?Wiqt~N[S@a?|1}eN' );

define( 'LOGGED_IN_KEY',    'cgTz*c|j_zaG%>-md(&A*+/[5Bl|FTDkuIJXr#UmW=BGj8[+{)b0Rc^^@XW/6 +6' );

define( 'NONCE_KEY',        ')EDGAu|PvVjs8i$CX7pV*i;qlNaG-A9DlBckW%[7^u=Nu.c.vR>[wh5:ePLjoN_7' );

define( 'AUTH_SALT',        'kc)oUF~JeHEgW+432jakvTzkmG0_1sF@!-y*(oK/@;;HM~pb&pqH~l!Q;t>og19j' );

define( 'SECURE_AUTH_SALT', 'Kq! )86(36bC$X``+9Jp=&43nc&9s8ba_A6kO9;;oQ6-h$y&yf_dt_H+?#8v=V%k' );

define( 'LOGGED_IN_SALT',   'd+t63@^j+{*1Hws1 Dtls$oo^(y{2$keVqQ$Wrihv2@(Y<Y.kH+|0[J$9&S@9XG5' );

define( 'NONCE_SALT',       '+jx[X%n6}3W?)%+bp1miNQ&sKWE|U_s[~u^N-g1BN7Q9RxgqgUhhuD,BL1mmyiK7' );


/**#@-*/

/**
 * Tiền tố cho bảng database.
 *
 * Đặt tiền tố cho bảng giúp bạn có thể cài nhiều site WordPress vào cùng một database.
 * Chỉ sử dụng số, ký tự và dấu gạch dưới!
 */
$table_prefix  = 'wp_';

/**
 * Dành cho developer: Chế độ debug.
 *
 * Thay đổi hằng số này thành true sẽ làm hiện lên các thông báo trong quá trình phát triển.
 * Chúng tôi khuyến cáo các developer sử dụng WP_DEBUG trong quá trình phát triển plugin và theme.
 *
 * Để có thông tin về các hằng số khác có thể sử dụng khi debug, hãy xem tại Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Đó là tất cả thiết lập, ngưng sửa từ phần này trở xuống. Chúc bạn viết blog vui vẻ. */

/** Đường dẫn tuyệt đối đến thư mục cài đặt WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Thiết lập biến và include file. */
require_once(ABSPATH . 'wp-settings.php');
